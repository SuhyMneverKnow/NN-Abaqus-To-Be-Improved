import matplotlib.pyplot as plt
import numpy as np

# ==========================================
# 1. 数据录入 (根据您提供的数据)
# ==========================================
alpha = np.array([0, 2.5, 5, 7.5, 10, 12.5, 15])           # 迎角 (度)
C_l   = np.array([0.052796, 0.05835, 0.063054, 0.07221, 0.093243, 0.186142, 0.239339]) # 升力系数
C_d   = np.array([0.034664, 0.03345, 0.038407, 0.045719, 0.05916, 0.117176, 0.150287]) # 阻力系数

# ==========================================
# 2. 绘图设置 (学术风格)
# ==========================================
# 设置字体和画布大小 (dpi=300 保证高清)
plt.rcParams['font.sans-serif'] = ['Arial']  # 如果需要中文支持可改为 ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
fig, ax1 = plt.subplots(figsize=(8, 6), dpi=300)

# ==========================================
# 3. 绘制升力系数 C_l (左轴 - 红色)
# ==========================================
color_cl = '#D62728' # 砖红色
ax1.set_xlabel('Angle of Attack $\\alpha$ (deg)', fontsize=13, fontweight='bold')
ax1.set_ylabel('Lift Coefficient ($C_l$)', color=color_cl, fontsize=13, fontweight='bold')
line1 = ax1.plot(alpha, C_l, color=color_cl, marker='o', markersize=8,
                 linewidth=2.5, label='Lift Coefficient ($C_l$)')
ax1.tick_params(axis='y', labelcolor=color_cl, labelsize=11)
ax1.tick_params(axis='x', labelsize=11)
ax1.grid(True, linestyle='--', alpha=0.5) # 背景虚线网格

# ==========================================
# 4. 绘制阻力系数 C_d (右轴 - 蓝色)
# ==========================================
ax2 = ax1.twinx()  # 创建共享x轴的第二个坐标轴
color_cd = '#1F77B4' # 经典蓝
ax2.set_ylabel('Drag Coefficient ($C_d$)', color=color_cd, fontsize=13, fontweight='bold')
line2 = ax2.plot(alpha, C_d, color=color_cd, marker='s', markersize=8,
                 linestyle='--', linewidth=2.5, label='Drag Coefficient ($C_d$)')
ax2.tick_params(axis='y', labelcolor=color_cd, labelsize=11)

# ==========================================
# 5. 合并图例与美化
# ==========================================
# 将两个轴的图例合并显示在左上角
lines = line1 + line2
labels = [l.get_label() for l in lines]
ax1.legend(lines, labels, loc='upper left', fontsize=11, frameon=True, shadow=True)

plt.title('Aerodynamic Characteristics: $C_l$ & $C_d$ vs. $\\alpha$', fontsize=15, pad=20)
plt.tight_layout()

# ==========================================
# 6. 保存与显示
# ==========================================
# 保存为高清图片文件
plt.savefig('Final_Aerodynamic_Curves.png', dpi=300)
print("图像已保存为 'Final_Aerodynamic_Curves.png'")
plt.show()