import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
from mpl_toolkits.mplot3d import Axes3D  # 确保导入3D绘图工具


# ==================== 参数配置区域 ====================
class DruckerPragerConfig:
    """Drucker-Prager模型参数配置类"""

    # 材料参数
    phi = 37.0  # 内摩擦角(度)
    C = 4.2  # 内聚力(MPa)
    phi_rad = phi * np.pi / 180.0
    sigma_t = -4.2
    alpha = 2 * np.sin(phi_rad) / (np.sqrt(3) * (3 - np.sin(phi_rad)))
    k = C * np.cos(phi_rad)

    # 计算范围参数
    I1_MIN = -k / alpha  # 第一应力不变量最小值(MPa)
    I1_MAX = 60.0  # 第一应力不变量最大值(MPa)
    I1_POINTS = 17  # I1方向的采样点数
    THETA_POINTS = 73  # Lode角方向的采样点数

    # 数值计算参数
    NEWTON_TOL = 1e-6  # 牛顿法容差
    NEWTON_MAX_ITER = 100  # 牛顿法最大迭代次数
    BISECTION_MAX_ITER = 50  # 二分法最大迭代次数

    # 绘图参数
    FIGURE_SIZE = (16, 12)  # 图形尺寸
    VIEW_ELEVATION = 25  # 3D视角仰角
    VIEW_AZIMUTH = 45  # 3D视角方位角

    # 数据保存参数
    SAVE_FILENAME = "InitialData.csv"  # 数据保存文件名


# 创建配置实例
config = DruckerPragerConfig()


# ==================== 核心计算函数 ====================
def drucker_prager_fail(phi, I1, R, theta, c):
    rad23 = np.sqrt(2 / 3)

    # 计算主应力
    sigma1 = I1 / 3 + rad23 * R * np.sin(theta + 2 / 3 * np.pi)
    sigma2 = I1 / 3 + rad23 * R * np.sin(theta)
    sigma3 = I1 / 3 + rad23 * R * np.sin(theta - 2 / 3 * np.pi)

    # 计算应力不变量
    p = sigma1 + sigma2 + sigma3  # in fact 3p
    S1 = sigma1 - p / 3
    S2 = sigma2 - p / 3
    S3 = sigma3 - p / 3

    # J2应力不变量
    J2 = 0.5 * (S1 ** 2 + S2 ** 2 + S3 ** 2)

    # Drucker-Prager破坏准则
    f1 = np.sqrt(J2) - (2 * np.sin(np.radians(phi)) / (np.sqrt(3) * (3 - np.sin(np.radians(phi))))) * I1 - c * np.cos(
        np.radians(phi))
    f2 = sigma1 - DruckerPragerConfig().sigma_t
    return min(f1, f2)


def newton_raphson(fai, I1, theta, c, tol, max_iter):
    # 初始猜测 - 基于I1调整
    if I1 < 0:
        R = 0.5
    else:
        R = 1.0

    for i in range(max_iter):
        # 计算当前函数值和导数值
        f_val = drucker_prager_fail(fai, I1, R, theta, c)

        # 如果f_val已经很小，直接返回
        if abs(f_val) < tol:
            return R

        # 使用有限差分计算导数
        h = max(1e-6, R * 1e-4)
        f_val_h = drucker_prager_fail(fai, I1, R + h, theta, c)
        df_dR = (f_val_h - f_val) / h

        # 避免除零
        if abs(df_dR) < 1e-10:
            break

        # 牛顿迭代更新
        delta = f_val / df_dR
        R_new = R - delta

        # 确保R不为负
        if R_new < 0:
            R_new = 0.01

        # 检查收敛性
        if abs(R_new - R) < tol:
            return R_new

        R = R_new

    # 如果牛顿法不收敛，尝试二分法
    return bisection_method(fai, I1, theta, c, tol, config.BISECTION_MAX_ITER)


def bisection_method(fai, I1, theta, c, tol, max_iter):
    R_low = 0.01
    R_high = 10.0

    f_low = drucker_prager_fail(fai, I1, R_low, theta, c)
    f_high = drucker_prager_fail(fai, I1, R_high, theta, c)

    if f_low * f_high > 0:
        # 没有根，返回边界值
        return R_low if abs(f_low) < abs(f_high) else R_high

    # 二分法
    for i in range(max_iter):
        R_mid = (R_low + R_high) / 2
        f_mid = drucker_prager_fail(fai, I1, R_mid, theta, c)

        if abs(f_mid) < tol:
            return R_mid

        if f_low * f_mid < 0:
            R_high = R_mid
            f_high = f_mid
        else:
            R_low = R_mid
            f_low = f_mid

    return (R_low + R_high) / 2


def calculate_stress_points():
    # 初始化参数
    I1_values = np.linspace(max(config.sigma_t, config.I1_MIN), config.I1_MAX, config.I1_POINTS)
    theta_values = np.linspace(0, 2 * np.pi, config.THETA_POINTS)

    # 网格数组：仅用于画2D轮廓线，保持 Grid 结构
    sig1_grid = np.zeros((len(I1_values), len(theta_values)))
    sig2_grid = np.zeros((len(I1_values), len(theta_values)))
    sig3_grid = np.zeros((len(I1_values), len(theta_values)))

    R_boundary_values = np.zeros((len(I1_values), len(theta_values)))

    print("计算应力点...")

    # 全量数据列表：用于保存CSV和画3D Scatter（包含盖子填充点）
    all_data_list = []

    # 定义需要进行“实心填充”的特殊 I1 值（对应 p = -1.4）
    target_I1_fill = -4.2

    for m, I1 in enumerate(I1_values):
        print(f" 处理 I1 = {I1:.1f} ({m + 1}/{len(I1_values)})")

        is_fill_layer = np.isclose(I1, target_I1_fill, atol=1e-3)

        for j, theta in enumerate(theta_values):
            # 1. 先求出边界上的 R (Rf)
            Rf = newton_raphson(config.phi, I1, theta, config.C, config.NEWTON_TOL, config.NEWTON_MAX_ITER)
            R_boundary_values[m, j] = Rf

            # 2. 决定在这个角度 theta 上要采多少个 R 点
            if is_fill_layer:
                # [关键逻辑] 特殊层，从圆心 0 到边界 Rf 均匀采样 25 个点，填满圆面
                current_r_samples = np.linspace(0, Rf, 25)
            else:
                # 正常层，只取边界点
                current_r_samples = [Rf]

            rad23 = np.sqrt(2 / 3)

            # 3. 填充 Grid 数组 (只存边界点，用于2D画图)
            # 只有当 R 是边界值时才放入 Grid 数组
            # 直接计算边界应力放入 Grid
            sig1_grid[m, j] = I1 / 3 + rad23 * Rf * np.sin(theta + 2 / 3 * np.pi)
            sig2_grid[m, j] = I1 / 3 + rad23 * Rf * np.sin(theta)
            sig3_grid[m, j] = I1 / 3 + rad23 * Rf * np.sin(theta - 2 / 3 * np.pi)

            # 4. 遍历采样点存入 List (用于3D画图和CSV)
            for r_val in current_r_samples:
                s1 = I1 / 3 + rad23 * r_val * np.sin(theta + 2 / 3 * np.pi)
                s2 = I1 / 3 + rad23 * r_val * np.sin(theta)
                s3 = I1 / 3 + rad23 * r_val * np.sin(theta - 2 / 3 * np.pi)

                # [p, rho, theta, s1, s2, s3, I1] -> 增加 I1 为了画图方便上色
                all_data_list.append([I1 / 3, r_val * rad23, theta, s1, s2, s3, I1])

    all_data_array = np.array(all_data_list)

    # 返回 Grid 数组(sig1_grid等) 用于2D图，返回 all_data_array 用于3D图
    return sig1_grid, sig2_grid, sig3_grid, theta_values, I1_values, R_boundary_values, all_data_array


# ==================== 保存函数 ====================
def save_data_to_csv(all_data_array, filename=None):
    if filename is None:
        filename = config.SAVE_FILENAME

    current_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(current_dir, filename)

    print(f"准备保存数据到: {filepath}")

    # all_data_array 列: [p, rho, theta, s1, s2, s3, I1]
    df = pd.DataFrame(all_data_array, columns=['p', 'rho', 'theta', 'sigma1', 'sigma2', 'sigma3', 'I1'])

    # 按需保留列
    df_save = df[['p', 'rho', 'theta']]

    df_save.to_csv(filepath, index=False, float_format='%.6f')

    print(f"数据已成功保存到: {filepath}")
    print(f"数据点数: {len(df)}")
    return df


# ==================== 绘图函数 (关键修改) ====================
def plot_drucker_prager_surface(sig1_grid, sig3_grid, theta_values, all_data_array):
    """
    修改后的绘图函数：
    - 2D图使用 sig1_grid (保持清晰的轮廓线)
    - 3D图使用 all_data_array (显示包含盖子在内的所有散点)
    """
    fig = plt.figure(figsize=config.FIGURE_SIZE)

    # --- 1. 绘制 2D 投影图 (使用 Grid 数据) ---
    ax3 = fig.add_subplot(111)

    theta_indices = [0, len(theta_values) // 4, len(theta_values) // 2,
                     3 * len(theta_values) // 4]

    for idx in theta_indices:
        ax3.plot(sig1_grid[:, idx], sig3_grid[:, idx], 'o-', linewidth=1.5,
                 markersize=3, label=f'θ={theta_values[idx]:.2f}')
    ax3.set_xlabel(r'$\sigma_1$ (MPa)', fontsize=12, fontname='Times New Roman')
    ax3.set_ylabel(r'$\sigma_3$ (MPa)', fontsize=12, fontname='Times New Roman')
    ax3.set_title('σ1-σ3 Projection', fontsize=12, fontname='Times New Roman')
    ax3.grid(True, alpha=0.3)
    ax3.legend()

    # --- 2. 绘制 3D 散点图 (使用 Full Data) ---
    fig2 = plt.figure(figsize=(14, 10))
    ax = fig2.add_subplot(111, projection='3d')

    # [关键修改] 这里不再flatten网格数据，而是直接从 all_data_array 取列
    # all_data_array 结构: [p, rho, theta, s1, s2, s3, I1]
    # 索引对应: s1=3, s2=4, s3=5, I1=6
    s1_all = all_data_array[:, 3]
    s2_all = all_data_array[:, 4]
    s3_all = all_data_array[:, 5]
    I1_all = all_data_array[:, 6]

    # 绘制散点
    scatter = ax.scatter(s1_all, s2_all, s3_all,
                         c=I1_all, cmap='viridis',
                         alpha=0.8, s=15, marker='o')  # alpha稍微调高，s调大，看清楚实心盖子

    ax.set_xlabel(r'$\sigma_1$ (MPa)', fontsize=14, fontname='Times New Roman')
    ax.set_ylabel(r'$\sigma_2$ (MPa)', fontsize=14, fontname='Times New Roman')
    ax.set_zlabel(r'$\sigma_3$ (MPa)', fontsize=14, fontname='Times New Roman')

    ax.view_init(elev=config.VIEW_ELEVATION, azim=config.VIEW_AZIMUTH)
    ax.set_title(f'Drucker-Prager Yield Surface with Solid Cap\n(fai={config.phi}°, c={config.C}MPa)',
                 fontsize=16, fontname='Times New Roman')

    cbar = fig2.colorbar(scatter, ax=ax, shrink=0.5, aspect=5)
    cbar.set_label('I1 (MPa)', fontsize=12, fontname='Times New Roman')
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


# ==================== 主函数 ====================
def main():
    print("=" * 60)
    print("Drucker-Prager模型参数配置:")
    print("=" * 60)
    print(f"内摩擦角 phi = {config.phi}°")
    print(f"内聚力 c = {config.C} MPa")
    print(f"I1采样点数: {config.I1_POINTS}")
    print(f"θ采样点数: {config.THETA_POINTS}")
    print("=" * 60)

    # 计算应力点
    print("开始计算应力点(包含实心盖子处理)...")
    # 接收更新后的返回值
    sig1_grid, sig2_grid, sig3_grid, theta_values, I1_values, R_values, all_data_array = calculate_stress_points()

    print(f"\n计算完成。总数据点数: {len(all_data_array)}")
    print(f"其中包含普通锥面点 + p=-1.4处的实心圆盘填充点")

    # 保存数据
    print("\n保存计算数据...")
    save_data_to_csv(all_data_array)

    # 绘制应力点图
    print("\n绘制应力点图像...")
    # 传入全量数据 all_data_array 用于 3D 绘图
    plot_drucker_prager_surface(sig1_grid, sig3_grid, theta_values, all_data_array)

    print("\n" + "=" * 60)
    print("程序执行完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()