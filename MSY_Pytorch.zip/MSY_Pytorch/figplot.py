import torch
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import joblib

# ==========================================
# 1. 设置路径和文件名
# ==========================================
data_file_path = "data/test_data.csv"   # 你的测试数据或者是训练数据路径
model_path     = "model/my_model.pth"   # 你的模型路径
# 如果有归一化文件 (Scaler)，请加载；如果没有，请忽略
scaler_input_path  = "model/input_scaler.pkl"
scaler_output_path = "model/output_scaler.pkl"

# ==========================================
# 2. 准备数据
# ==========================================
# 读取数据 (假设是 CSV，如果是 Excel 用 pd.read_excel)
df = pd.read_csv(data_file_path)

# 假设前3列是输入(比如应变)，第4列是真实输出(比如应力)
# 请根据你的实际列名修改！
input_data = df.iloc[:, 0:3].values  # 取所有行，前3列作为输入
true_label = df.iloc[:, 3].values    # 取所有行，第4列作为真实标签

# 转换为 Tensor
inputs = torch.tensor(input_data, dtype=torch.float32)

# ==========================================
# 3. 加载模型并预测
# ==========================================
# 加载模型
model = torch.load(model_path)
model.eval() # 设置为评估模式 (非常重要！)

# 如果有归一化，先对输入进行归一化
try:
    scaler_in = joblib.load(scaler_input_path)
    # inputs_numpy = scaler_in.transform(input_data)
    # inputs = torch.tensor(inputs_numpy, dtype=torch.float32)
    pass # 暂时跳过，如果你需要请取消注释
except:
    print("未加载 Scaler，使用原始数据直接输入")

# --- 核心步骤：让模型进行预测 ---
with torch.no_grad(): # 预测时不需要计算梯度，节省内存
    prediction = model(inputs)

# 转回 numpy 格式方便绘图
predicted_label = prediction.numpy()

# 如果输出有归一化，需要反归一化回真实物理量
try:
    scaler_out = joblib.load(scaler_output_path)
    # predicted_label = scaler_out.inverse_transform(predicted_label)
    pass
except:
    pass

# ==========================================
# 4. 绘图：把你所有的点都画出来
# ==========================================

# 图1：逐点对比 (样本序号 vs 数值)
plt.figure(figsize=(10, 5))
plt.plot(true_label, 'k.', label='Ground Truth (Original Data)', markersize=5, alpha=0.5)
plt.plot(predicted_label, 'r-', label='NN Prediction', linewidth=1)
plt.title("Comparison: Real Data vs Neural Network Prediction")
plt.xlabel("Sample Index")
plt.ylabel("Output Value")
plt.legend()
plt.show()

# 图2：散点相关性图 (横轴是真实值，纵轴是预测值)
# 完美的预测应该落在 45度 对角线上
plt.figure(figsize=(6, 6))
plt.scatter(true_label, predicted_label, c='blue', alpha=0.5, s=10)
plt.plot([true_label.min(), true_label.max()], [true_label.min(), true_label.max()], 'k--', lw=2) # 对角线
plt.title("Correlation Plot")
plt.xlabel("True Value")
plt.ylabel("Predicted Value")
plt.grid(True)
plt.show()

# ==========================================
# 5. 计算误差
# ==========================================
mse = np.mean((true_label - predicted_label.flatten())**2)
print(f"均方误差 (MSE): {mse:.6f}")