import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
from mpl_toolkits.mplot3d import Axes3D


# ==================== 参数配置区域 ====================
class DruckerPragerConfig:
    # 材料参数
    phi = 37.0
    C = 4.2
    phi_rad = phi * np.pi / 180.0
    sigma_t = -4.2
    alpha = 2 * np.sin(phi_rad) / (np.sqrt(3) * (3 - np.sin(phi_rad)))
    k = C * np.cos(phi_rad)

    # 计算范围参数
    I1_MIN = -k / alpha
    I1_MAX = 60.0
    I1_POINTS = 17
    THETA_POINTS = 73

    # 数值计算参数
    NEWTON_TOL = 1e-6
    NEWTON_MAX_ITER = 100
    BISECTION_MAX_ITER = 50

    # 绘图参数
    FIGURE_SIZE = (16, 12)
    VIEW_ELEVATION = 25
    VIEW_AZIMUTH = 45

    # 数据保存参数 - 修改文件名
    SAVE_FILENAME = "InitialData_NoLid.csv"


config = DruckerPragerConfig()


# ==================== 核心计算函数 ====================
def drucker_prager_fail(phi, I1, R, theta, c):
    rad23 = np.sqrt(2 / 3)
    sigma1 = I1 / 3 + rad23 * R * np.sin(theta + 2 / 3 * np.pi)
    sigma2 = I1 / 3 + rad23 * R * np.sin(theta)
    sigma3 = I1 / 3 + rad23 * R * np.sin(theta - 2 / 3 * np.pi)

    p = sigma1 + sigma2 + sigma3
    S1 = sigma1 - p / 3
    S2 = sigma2 - p / 3
    S3 = sigma3 - p / 3
    J2 = 0.5 * (S1 ** 2 + S2 ** 2 + S3 ** 2)

    f1 = np.sqrt(J2) - (2 * np.sin(np.radians(phi)) / (np.sqrt(3) * (3 - np.sin(np.radians(phi))))) * I1 - c * np.cos(
        np.radians(phi))
    f2 = sigma1 - DruckerPragerConfig().sigma_t
    return min(f1, f2)


def newton_raphson(fai, I1, theta, c, tol, max_iter):
    if I1 < 0:
        R = 0.5
    else:
        R = 1.0

    for i in range(max_iter):
        f_val = drucker_prager_fail(fai, I1, R, theta, c)
        if abs(f_val) < tol: return R

        h = max(1e-6, R * 1e-4)
        f_val_h = drucker_prager_fail(fai, I1, R + h, theta, c)
        df_dR = (f_val_h - f_val) / h

        if abs(df_dR) < 1e-10: break

        R_new = R - f_val / df_dR
        if R_new < 0: R_new = 0.01

        if abs(R_new - R) < tol: return R_new
        R = R_new

    return bisection_method(fai, I1, theta, c, tol, config.BISECTION_MAX_ITER)


def bisection_method(fai, I1, theta, c, tol, max_iter):
    R_low, R_high = 0.01, 10.0
    f_low = drucker_prager_fail(fai, I1, R_low, theta, c)
    f_high = drucker_prager_fail(fai, I1, R_high, theta, c)

    if f_low * f_high > 0:
        return R_low if abs(f_low) < abs(f_high) else R_high

    for i in range(max_iter):
        R_mid = (R_low + R_high) / 2
        f_mid = drucker_prager_fail(fai, I1, R_mid, theta, c)
        if abs(f_mid) < tol: return R_mid

        if f_low * f_mid < 0:
            R_high, f_high = R_mid, f_mid
        else:
            R_low, f_low = R_mid, f_mid
    return (R_low + R_high) / 2


# === 这里的 calculate_stress_points 是改动最关键的地方 ===
# 去掉了“实心填充”逻辑，只计算边界
def calculate_stress_points():
    I1_values = np.linspace(max(config.sigma_t, config.I1_MIN), config.I1_MAX, config.I1_POINTS)
    theta_values = np.linspace(0, 2 * np.pi, config.THETA_POINTS)

    sig1_grid = np.zeros((len(I1_values), len(theta_values)))
    sig2_grid = np.zeros((len(I1_values), len(theta_values)))
    sig3_grid = np.zeros((len(I1_values), len(theta_values)))
    R_boundary_values = np.zeros((len(I1_values), len(theta_values)))

    all_data_list = []
    rad23 = np.sqrt(2 / 3)

    print("计算应力点 (No Lid Mode)...")

    for m, I1 in enumerate(I1_values):
        for j, theta in enumerate(theta_values):
            # 1. 计算边界 Rf
            Rf = newton_raphson(config.phi, I1, theta, config.C, config.NEWTON_TOL, config.NEWTON_MAX_ITER)
            R_boundary_values[m, j] = Rf

            # 2. 存入 grid
            sig1_grid[m, j] = I1 / 3 + rad23 * Rf * np.sin(theta + 2 / 3 * np.pi)
            sig2_grid[m, j] = I1 / 3 + rad23 * Rf * np.sin(theta)
            sig3_grid[m, j] = I1 / 3 + rad23 * Rf * np.sin(theta - 2 / 3 * np.pi)

            # 3. 存入 list (不再进行内部循环，只存边界点)
            all_data_list.append([
                I1 / 3,
                Rf * rad23,
                theta,
                sig1_grid[m, j],
                sig2_grid[m, j],
                sig3_grid[m, j],
                I1
            ])

    return sig1_grid, sig2_grid, sig3_grid, theta_values, I1_values, R_boundary_values, np.array(all_data_list)


def save_data_to_csv(all_data_array, filename=None):
    if filename is None: filename = config.SAVE_FILENAME
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    df = pd.DataFrame(all_data_array, columns=['p', 'rho', 'theta', 'sigma1', 'sigma2', 'sigma3', 'I1'])
    df[['p', 'rho', 'theta']].to_csv(filepath, index=False, float_format='%.6f')
    print(f"Saved to: {filepath}")


def plot_drucker_prager_surface(sig1_grid, sig3_grid, theta_values, all_data_array):
    fig = plt.figure(figsize=config.FIGURE_SIZE)

    # 2D Plot
    ax3 = fig.add_subplot(111)
    theta_indices = [0, len(theta_values) // 4, len(theta_values) // 2, 3 * len(theta_values) // 4]
    for idx in theta_indices:
        ax3.plot(sig1_grid[:, idx], sig3_grid[:, idx], 'o-', label=f'θ={theta_values[idx]:.2f}')
    ax3.legend()
    ax3.set_title('σ1-σ3 Projection')

    # 3D Plot
    fig2 = plt.figure(figsize=(14, 10))
    ax = fig2.add_subplot(111, projection='3d')
    scatter = ax.scatter(all_data_array[:, 3], all_data_array[:, 4], all_data_array[:, 5],
                         c=all_data_array[:, 6], cmap='viridis', alpha=0.6, s=15)
    ax.set_title(f'Drucker-Prager Yield Surface (No Lid)')
    plt.show()


if __name__ == "__main__":
    print(f"Phi={config.phi}, C={config.C}")
    data = calculate_stress_points()
    save_data_to_csv(data[6])
    plot_drucker_prager_surface(data[0], data[2], data[3], data[6])