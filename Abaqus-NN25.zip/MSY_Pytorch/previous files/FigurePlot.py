import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.colors as mcolors
import sys

# 添加路径以导入您的坐标转换函数
sys.path.insert(0, './offline_training')
from util.coordinate_transforms import convert_prt_to_123

# 读取生成的CSV数据
try:
    data = pd.read_csv('InitialData.csv')
    p = data['p'].values
    rho = data['rho'].values
    theta = data['theta'].values

    print(f"数据加载成功!")
    print(f"数据点数: {len(p)}")
    print(f"p范围: [{p.min():.2f}, {p.max():.2f}]")
    print(f"rho范围: [{rho.min():.2f}, {rho.max():.2f}]")
    print(f"theta范围: [{theta.min():.2f}, {theta.max():.2f}]")

except FileNotFoundError:
    print("错误: 找不到InitialData.csv文件")
    print("请确保文件在当前目录下")
    exit()

# 使用您的函数将圆柱坐标转换回主应力
print("正在进行坐标转换...")
sigma1, sigma2, sigma3 = convert_prt_to_123(p, rho, theta)

print(f"主应力范围:")
print(f"sigma1: [{sigma1.min():.2f}, {sigma1.max():.2f}]")
print(f"sigma2: [{sigma2.min():.2f}, {sigma2.max():.2f}]")
print(f"sigma3: [{sigma3.min():.2f}, {sigma3.max():.2f}]")

# 创建主可视化图形
plt.rcParams['font.sans-serif'] = ['SimHei']  # 支持中文显示
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号

fig = plt.figure(figsize=(18, 5))

# 1. 3D主应力空间图
ax1 = fig.add_subplot(131, projection='3d')
scatter1 = ax1.scatter(sigma1, sigma2, sigma3, c=p, cmap='viridis',
                       alpha=0.6, s=1)
ax1.set_xlabel(r'$\sigma_1$ (MPa)', fontsize=12)
ax1.set_ylabel(r'$\sigma_2$ (MPa)', fontsize=12)
ax1.set_zlabel(r'$\sigma_3$ (MPa)', fontsize=12)
ax1.set_title('Drucker-Prager准则 - 3D主应力空间', fontsize=12)
plt.colorbar(scatter1, ax=ax1, label='静水压力 p (MPa)')

# 2. π平面投影
ax2 = fig.add_subplot(132)
s1 = sigma1 - p
s2 = sigma2 - p
s3 = sigma3 - p
xi = (s1 - s3) / np.sqrt(2)
eta = (2 * s2 - s1 - s3) / np.sqrt(6)

scatter2 = ax2.scatter(xi, eta, c=rho, cmap='plasma', alpha=0.6, s=1)
ax2.set_xlabel(r'$\xi$', fontsize=12)
ax2.set_ylabel(r'$\eta$', fontsize=12)
ax2.set_title('Drucker-Prager准则 - π平面投影', fontsize=12)
ax2.grid(True, alpha=0.3)
ax2.set_aspect('equal')
plt.colorbar(scatter2, ax=ax2, label='偏应力半径 $\\rho$ (MPa)')

# 3. sigma1-sigma2平面截面
ax3 = fig.add_subplot(133)
theta_tolerance = 0.1
mask = (np.abs(theta) < theta_tolerance) | (np.abs(theta - 2 * np.pi) < theta_tolerance)
scatter3 = ax3.scatter(sigma1[mask], sigma2[mask], c=rho[mask], cmap='hot',
                       alpha=0.7, s=3)
ax3.set_xlabel(r'$\sigma_1$ (MPa)', fontsize=12)
ax3.set_ylabel(r'$\sigma_2$ (MPa)', fontsize=12)
ax3.set_title(r'Drucker-Prager准则 - $\sigma_1$-$\sigma_2$平面', fontsize=12)
ax3.grid(True, alpha=0.3)
ax3.set_aspect('equal')
plt.colorbar(scatter3, ax=ax3, label='偏应力半径 $\\rho$ (MPa)')

plt.tight_layout()
plt.show()

# 统计分析
print(f"\n破坏面统计分析:")
print(f"平均偏应力半径: {rho.mean():.2f} MPa")
print(f"偏应力半径标准差: {rho.std():.2f} MPa")
print(f"最大偏应力半径: {rho.max():.2f} MPa")
print(f"最小偏应力半径: {rho.min():.2f} MPa")
