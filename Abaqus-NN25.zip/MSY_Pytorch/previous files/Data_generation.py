import sys
import pandas as pd
import autograd.numpy as np
from autograd import elementwise_grad as egrad

sys.path.insert(0, './offline_training')
from util.coordinate_transforms import *

# INPUT --------------------------------------------------------
# Material properties
E = 80e3  # Young's modulus [MPa]
sigma_y = 250.0  # Initial yield stress [MPa]
phi_deg = 37  # friction_angle [°]
c = 4.2  # Cohension [MPa]
sigma_t = 4.2  # Tensile stength [MPa]
phi_rad = phi_deg * np.pi / 180.0
file_name = 'InitialData'

# 步骤2：计算 alpha 和 k
alpha = np.sin(phi_rad) / (np.sqrt(3) * (3 - np.sin(phi_rad)))
k = (np.sqrt(3) * c * np.cos(phi_rad)) / (3 - np.sin(phi_rad))

print(f"Material parameters: alpha = {alpha:.6f}, k = {k:.6f}")


# Model function
def f(p, rho, theta):
    sigma1, sigma2, sigma3 = convert_prt_to_123(p, rho, theta)

    J1 = sigma1 + sigma2 + sigma3
    J2 = 1 / 6 * ((sigma1 - sigma2) ** 2 + (sigma3 - sigma2) ** 2 + (sigma1 - sigma3) ** 2)

    # 防止J2为负数（数值误差）
    J2 = np.maximum(J2, 1e-16)

    f_val = alpha * J1 + np.sqrt(J2) - k
    return f_val


# Data range
# p: (1/3)*tr(sigma) [MPa]
min_p = - sigma_t
max_p = 2e3
N_p = 20

# theta: Lode's angle [rad]
min_theta = 0
max_theta = 2 * np.pi
N_theta = 50

# Generate equally-spaced stress points in cylindrical coordinates
p = np.linspace(min_p, max_p, N_p)
theta = np.linspace(min_theta, max_theta, N_theta + 1)[0:N_theta]

p_nd, theta_nd = np.meshgrid(p, theta)

# 直接展平为一维数组
p_nd = p_nd.ravel()
theta_nd = theta_nd.ravel()

# Compute rho based on model function
rho_nd = np.zeros_like(p_nd)
get_dfdrho = egrad(f, 1)

maxiter = 200
tol = 1e-11

converged_count = 0
failed_count = 0


def get_initial_guess(p_val, theta_val, alpha, k, c, phi_rad):
    """根据p和theta提供更好的初始猜测"""
    k0 = (np.sqrt(3) * c * np.cos(phi_rad)) / (3 - np.sin(phi_rad))

    # 基本估计基于p
    if p_val >= 0:
        base_guess = max(k / alpha, k0 * np.sqrt(2))
    else:
        base_guess = k0 * np.sqrt(2)

    # 根据theta调整初始猜测
    # 对于不同的Lode角，屈服面的形状会变化
    theta_norm = (theta_val % (2 * np.pi)) / (2 * np.pi)

    # 在theta=pi/6和5pi/6附近（对应三轴压缩和拉伸）需要特别处理
    if abs(theta_val - np.pi / 6) < 0.1 or abs(theta_val - 5 * np.pi / 6) < 0.1:
        # 这些位置通常需要较小的rho值
        factor = 0.8
    elif abs(theta_val - np.pi / 2) < 0.2:
        # 中间位置可能需要较大的rho值
        factor = 1.2
    else:
        # 其他位置使用基于三角函数的变化
        factor = 1.0 + 0.3 * np.sin(3 * theta_val)

    return base_guess * factor


print(f"Starting Newton iteration for {len(p_nd)} points...")
print(f"Theta range: {min_theta:.3f} to {max_theta:.3f} rad")

for i in range(np.shape(p_nd)[0]):
    # 使用改进的初始猜测，考虑theta的影响
    x = get_initial_guess(p_nd[i], theta_nd[i], alpha, k, c, phi_rad)

    print(
        f">> Point {i}: p={p_nd[i]:.3f}, theta={theta_nd[i]:.3f} rad ({theta_nd[i] * 180 / np.pi:.1f}°) --------------------")

    converged = False
    for ii in range(maxiter):
        res = f(p_nd[i], x, theta_nd[i])
        jac = get_dfdrho(p_nd[i], x, theta_nd[i])

        # 检查雅可比矩阵是否太小
        if abs(jac) < 1e-12:
            # 如果雅可比太小，使用固定步长
            dx = -np.sign(res) * min(0.1 * abs(x), 1.0)
            print(f"  Small jacobian detected, using fixed step: {dx:.6f}")
        else:
            dx = -res / jac

        # 限制步长，防止振荡
        max_step = 0.5 * abs(x) if abs(x) > 1e-6 else 1.0
        if abs(dx) > max_step:
            dx = np.sign(dx) * max_step
            print(f"  Step limited to: {dx:.6f}")

        x_old = x
        x = x + dx

        err = np.linalg.norm(dx)
        res_abs = abs(res)

        if ii % 10 == 0:  # 减少输出频率
            print(f"  Newton iter.{ii}: err = {err:.3e}, res = {res_abs:.3e}, x = {x:.6f}, jac = {jac:.6e}")

        # 检查收敛
        if err < tol and res_abs < tol:
            rho_nd[i] = x
            converged = True
            converged_count += 1
            print(f"  *** Converged in {ii + 1} iterations ***")
            break

        # 检查是否发散
        if np.isnan(x) or np.isinf(x) or abs(res) > 1e10:
            print(f"  *** Diverged at iteration {ii} ***")
            break

    if not converged:
        # 尝试使用二分法作为备用方案，考虑theta的影响
        print("  Newton failed, trying bisection...")
        rho_low, rho_high = 1e-6, 1e4

        # 根据theta调整二分法范围
        if theta_nd[i] < np.pi / 3:
            rho_high = 2e3
        elif theta_nd[i] > 2 * np.pi / 3:
            rho_high = 1.5e3

        for bisect_iter in range(50):
            rho_mid = 0.5 * (rho_low + rho_high)
            f_mid = f(p_nd[i], rho_mid, theta_nd[i])

            if abs(f_mid) < tol:
                rho_nd[i] = rho_mid
                converged = True
                converged_count += 1
                print(f"  *** Bisection converged in {bisect_iter + 1} iterations ***")
                break
            elif f_mid > 0:
                rho_high = rho_mid
            else:
                rho_low = rho_mid

            if bisect_iter % 10 == 0:
                print(f"  Bisection iter.{bisect_iter}: rho_mid = {rho_mid:.6f}, res = {f_mid:.3e}")

        if not converged:
            failed_count += 1
            # 使用最后一次牛顿迭代值或基于theta的保守估计
            fallback_guess = get_initial_guess(p_nd[i], theta_nd[i], alpha, k, c, phi_rad) * 0.5
            rho_nd[i] = x if not (np.isnan(x) or np.isinf(x)) else fallback_guess
            print(f"  *** All methods failed, using approximate value: {rho_nd[i]:.6f} ***")

print(f"\n=== Summary ===")
print(f"Total points: {len(p_nd)}")
print(f"Converged: {converged_count}")
print(f"Failed: {failed_count}")
print(f"Success rate: {converged_count / len(p_nd) * 100:.1f}%")

# 验证最终结果，按theta分组显示
print(f"\n=== Final validation (grouped by theta) ===")
unique_thetas = np.unique(theta_nd)
for theta_val in unique_thetas[:5]:  # 显示前5个不同的theta值
    indices = np.where(theta_nd == theta_val)[0][:2]  # 每个theta显示2个点
    for idx in indices:
        final_res = f(p_nd[idx], rho_nd[idx], theta_nd[idx])
        print(
            f"Theta={theta_val * 180 / np.pi:5.1f}°: p={p_nd[idx]:8.3f}, rho={rho_nd[idx]:8.3f}, residual={final_res:.6f}")

# Save output
p_nd = p_nd.reshape((-1, 1))
rho_nd = rho_nd.reshape((-1, 1))
theta_nd = theta_nd.reshape((-1, 1))

data = np.hstack((p_nd, rho_nd, theta_nd))

output = pd.DataFrame({
    'p': data[:, 0],
    'rho': data[:, 1],
    'theta': data[:, 2]
})

output.to_csv("./" + file_name + ".csv", index=False)

print(f"\nData saved to {file_name}.csv")