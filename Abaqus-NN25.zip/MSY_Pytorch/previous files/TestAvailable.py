import torch
x = torch.rand(5, 3)
print(x)
torch.cuda.is_available()