import torch
import numpy as np
import matplotlib.pyplot as plt
import joblib
import pandas as pd
import os

# ================= 配置部分 =================
model_path = "./Training_Data_File/train_f/"
data_path = "./training_data.csv"  # 确保这里有你的原始数据文件
# 选择你要画的切面角度 (弧度制)
# theta = 0 (纯剪切/压缩子午线附近，视定义而定)
# theta = pi/3 (拉伸子午线)
target_theta = 0.0
# ===========================================

# 1. 加载模型和缩放器
# 注意：weights_only=False 首字母要大写
f_net = torch.load(model_path + "f_NN.pth", map_location=torch.device('cpu'), weights_only=False)
f_net.eval()

input_scaler = joblib.load(model_path + "f_INPUT_scaler.pkl")
output_scaler = joblib.load(model_path + "f_OUTPUT_scaler.pkl")

# 2. 准备绘制“红线”的数据 (神经网络预测)
# 生成 2D 网格 (p, rho)
p_range = np.linspace(-10, 50, 200)  # 根据你的数据范围调整
rho_range = np.linspace(0, 30, 200)  # 根据你的数据范围调整
P, RHO = np.meshgrid(p_range, rho_range)

# 创建输入张量，注意 Theta 固定为 target_theta
THETA = np.full_like(P, target_theta)

# 拼接成 (N, 3) 格式
grid_points = np.vstack([P.ravel(), RHO.ravel(), THETA.ravel()]).T

# 归一化输入
grid_points_scaled = input_scaler.transform(grid_points)
grid_tensor = torch.tensor(grid_points_scaled, dtype=torch.float)

# 神经网络预测
with torch.no_grad():
    f_pred_scaled = f_net(grid_tensor).numpy()

# 反归一化输出 (虽然找0等值线不需要反归一化，但为了严谨还原数值)
f_pred = output_scaler.inverse_transform(f_pred_scaled).reshape(P.shape)

# 3. 准备绘制“蓝点”的数据 (原始训练数据)
# 这一步是为了画出散点图，看拟合效果
if os.path.exists(data_path):
    df = pd.read_csv(data_path)
    tolerance = np.deg2rad(1)
    mask = (df['theta'] >= target_theta - tolerance) & (df['theta'] <= target_theta + tolerance)

    data_p = df.loc[mask, 'p'].values
    data_rho = df.loc[mask, 'rho'].values

else:
    print("未找到训练数据文件，将只绘制拟合曲线。")
    data_p, data_rho = [], []

# 4. 绘图
fig, ax = plt.subplots(figsize=(8, 6))

# A. 画蓝点 (原始数据)
if len(data_p) > 0:
    ax.scatter(data_p, data_rho, c='blue', alpha=0.5, s=20, label='Raw Data')

# B. 画红线 (神经网络零等值线)
# levels=[0] 表示只画 f=0 的那条线
contour = ax.contour(P, RHO, f_pred, levels=[0], colors='red', linewidths=2)

# 为了图例能显示红线，创建一个虚拟的plot对象
fake_line, = ax.plot([], [], color='red', linewidth=2, label='NN Prediction ($f=0$)')

# C. 装饰图片
ax.set_xlabel(r'$p$ (MPa)', fontsize=14)
# 如果你的 rho = sqrt(2J2)，那么这里坐标轴标签如下
ax.set_ylabel(r'$\rho$ ($\approx \sqrt{2 J_2}$) (MPa)', fontsize=14)
# 如果你想完全复刻参考图的 sqrt(J2)，记得把上面的数据除以 sqrt(2)

ax.set_title(f'Yield Surface Meridian Plane ($\\theta={target_theta:.2f}$ rad)', fontsize=16)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend()

plt.tight_layout()
plt.show()